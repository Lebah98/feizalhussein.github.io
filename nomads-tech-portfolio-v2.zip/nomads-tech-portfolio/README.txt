NOMADS TECH PORTFOLIO

Open index.html in a browser. This is a responsive single-file website.
Before publishing: replace contact placeholders with your real email/WhatsApp and verify all externally hosted images. PastoraLink features are labelled as proposed/in development.

To publish: upload index.html to a static hosting service such as Netlify. External photos require internet access.
